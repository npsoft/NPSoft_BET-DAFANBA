namespace Pechkin.EventHandlers
{
    public delegate void ErrorEventHandler(SimplePechkin converter, string errorText);
}