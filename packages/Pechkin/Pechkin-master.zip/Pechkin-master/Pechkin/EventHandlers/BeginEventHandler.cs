namespace Pechkin.EventHandlers
{
    public delegate void BeginEventHandler(SimplePechkin converter, int expectedPhaseCount);
}