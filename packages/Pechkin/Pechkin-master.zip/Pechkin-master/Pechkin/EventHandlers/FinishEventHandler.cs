namespace Pechkin.EventHandlers
{
    public delegate void FinishEventHandler(SimplePechkin converter, bool success);
}