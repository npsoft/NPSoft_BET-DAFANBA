namespace Html2Pdf.EventHandlers
{
    public delegate void LibInitEventHandler();
}