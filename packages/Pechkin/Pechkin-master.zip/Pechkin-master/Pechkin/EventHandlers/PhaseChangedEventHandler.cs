namespace Pechkin.EventHandlers
{
    public delegate void PhaseChangedEventHandler(SimplePechkin converter, int phaseNumber, string phaseDescription);
}