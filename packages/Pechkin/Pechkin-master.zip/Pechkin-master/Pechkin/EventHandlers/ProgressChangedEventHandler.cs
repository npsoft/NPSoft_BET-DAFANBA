namespace Pechkin.EventHandlers
{
    public delegate void ProgressChangedEventHandler(SimplePechkin converter, int progress, string progressDescription);
}