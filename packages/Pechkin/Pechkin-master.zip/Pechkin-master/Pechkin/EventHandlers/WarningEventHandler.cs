namespace Pechkin.EventHandlers
{
    public delegate void WarningEventHandler(SimplePechkin converter, string warningText);
}