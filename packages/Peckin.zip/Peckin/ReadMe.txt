﻿1. Links
- gmanny/Pechkin · GitHub :: https://github.com/gmanny/Pechkin
2. Example #1
- Libs
(1): Pechkin.dll
(2): Pechkin.Synchronized.dll
(3): libeay32.dll(bin folder)
(4): libgcc_s_dw2-1.dll(bin folder)
(5): mingwm10.dll(bin folder)
(6): ssleay32.dll(bin folder)
(7): wkhtmltox0.dll(bin folder)
- Files
OrderReportController.cs(NPSoft_HTQLNHCS)
