<?php
require_once('../root_app_path.php');
set_include_path(implode(PATH_SEPARATOR, array(APPLICATION_PATH . '/../library', get_include_path())));
require_once "main.php"; //in library
?>